console.log ("Hello!  Welcome to Danielle's webiste!")
